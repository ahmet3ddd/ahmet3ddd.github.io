# Ilk deneme (22 Kasim 2026): Brown derlemi (NLTK dagitimi, Ingilizce, 15 tur) ve TTC-3600 (Turkce haber, 6 kategori).
# Veri: Brown -> https://raw.githubusercontent.com/nltk/nltk_data/gh-pages/packages/corpora/brown.zip ; TTC-3600 -> https://github.com/denopas/TTC-3600
# Klasorleri D degiskeninin gosterdigi yere acin: brown/ ve ttcx/TTC-3600_Orj/<kategori>/*.txt
# Gerekenler: numpy, scikit-learn. Calistirma: python3 ilk-deneme-brown-ttc3600.py

import os, re, glob, json, random
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import GroupKFold, cross_val_predict
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import accuracy_score, balanced_accuracy_score

random.seed(0); np.random.seed(0)
D = '/home/claude/data'
CH = 200  # kelime/parça
WIDTH = 60  # görsel satır genişliği (karakter)

def load_brown():
    cats = {}
    for l in open(f'{D}/brown/cats.txt'):
        f, c = l.split()[:2]; cats[f] = c
    docs = []
    for f, c in cats.items():
        txt = open(f'{D}/brown/{f}').read()
        toks = [t.rsplit('/', 1)[0] for t in txt.split()]
        # noktalamayı önceki kelimeye yapıştır (gerçek metin görünümü)
        words = []
        for t in toks:
            if re.fullmatch(r"[^\w]+", t) and words: words[-1] += t
            else: words.append(t)
        docs.append((c, f, words))
    return docs

def load_ttc():
    docs = []
    for p in glob.glob(f'{D}/ttcx/TTC-3600_Orj/*/*.txt'):
        c = p.split('/')[-2]
        txt = open(p, encoding='utf-8-sig', errors='ignore').read()
        docs.append((c, p, txt.split()))
    return docs

def chunks(docs):
    X = []
    for c, f, w in docs:
        for i in range(0, len(w) - CH + 1, CH):
            X.append((c, f, w[i:i+CH]))
    return X

def L(w): return len(re.sub(r"[^\w]", "", w)) or 1

def layout(words):
    """Metni sabit genişlikte satırlara diz; her satırdaki boşluk konumlarını döndür."""
    lines, cur, pos = [], [], 0
    for w in words:
        n = len(w)
        if pos + n > WIDTH and pos > 0:
            lines.append(cur); cur, pos = [], 0
        pos += n
        cur.append(pos + 0.5)  # boşluğun x'i
        pos += 1
    lines.append(cur)
    return [l[:-1] for l in lines]  # satır sonu boşluğu sayılmaz

def river(words):
    """Boşluk dallanması: her boşluk için alt satırdaki en yakın boşluğa yatay mesafe.
    Küçük mesafe = dikey dallanma, büyük = yatay."""
    ls = layout(words); d = []
    for a, b in zip(ls, ls[1:]):
        if not a or not b: continue
        b = np.array(b)
        for x in a: d.append(np.min(np.abs(b - x)))
    d = np.array(d) if d else np.array([0.])
    vert = np.mean(d <= 1.0)  # neredeyse dikey bağlantı oranı
    return [d.mean(), np.median(d), vert]

def feats(words, kind):
    l = np.array([L(w) for w in words])
    h = np.bincount(np.clip(l, 1, 15), minlength=16)[1:] / len(l)
    base = [l.mean(), l.std(), np.mean(l <= 3), np.mean(l >= 8)]
    if kind == 'ort': return [l.mean()]
    if kind == 'hist': return list(h) + base
    seq = [np.corrcoef(l[:-1], l[1:])[0, 1]]
    tr = np.zeros((3, 3))  # kısa/orta/uzun geçişleri
    b = np.digitize(l, [4, 8])
    for x, y in zip(b, b[1:]): tr[x, y] += 1
    seq += list((tr / tr.sum()).ravel())
    if kind == 'sira': return list(h) + base + seq
    if kind == 'gorsel': return river(words)
    if kind == 'hepsi': return list(h) + base + seq + river(words)

def cv(X, y, g):
    m = make_pipeline(StandardScaler(), LogisticRegression(max_iter=3000, C=1.0))
    p = cross_val_predict(m, X, y, groups=g, cv=GroupKFold(5))
    return balanced_accuracy_score(y, p), p

def run(name, docs, order=None):
    ck = chunks(docs)
    y = np.array([c for c, _, _ in ck]); g = np.array([f for _, f, _ in ck])
    classes = sorted(set(y)); chance = 1 / len(classes)
    out = {'veri': name, 'parca': len(ck), 'sinif': len(classes), 'sans': chance}
    # 1) tür başına ortalama kelime uzunluğu ve dallanma
    prof = {}
    for c in classes:
        sel = [w for cc, _, w in ck if cc == c]
        ml = np.mean([np.mean([L(x) for x in w]) for w in sel])
        rv = np.mean([river(w) for w in sel], axis=0)
        prof[c] = {'ort_uzunluk': round(ml, 3), 'yatay_mesafe': round(rv[0], 3), 'dikey_oran': round(rv[2], 3)}
    out['profil'] = prof
    # korelasyon: uzunluk vs dallanma (parça düzeyi)
    sample = random.sample(ck, min(3000, len(ck)))
    ml = [np.mean([L(x) for x in w]) for _, _, w in sample]
    rd = [river(w)[0] for _, _, w in sample]
    out['uzunluk_dallanma_r'] = round(float(np.corrcoef(ml, rd)[0, 1]), 3)
    # 2) sınıflandırma
    res = {}
    for k in ['ort', 'hist', 'sira', 'gorsel', 'hepsi']:
        X = np.nan_to_num(np.array([feats(w, k) for _, _, w in ck]))
        res[k], p = cv(X, y, g)
        if k == 'hepsi': pbest = p
    # kontrol: kelimeleri parça içinde karıştır (sıra bilgisi yok olur)
    shuf = []
    for _, _, w in ck:
        w = list(w); random.shuffle(w); shuf.append(w)
    X = np.nan_to_num(np.array([feats(w, 'hepsi') for w in shuf]))
    res['hepsi_karisik'], _ = cv(X, y, g)
    # kontrol: etiketleri karıştır
    yy = y.copy(); np.random.shuffle(yy)
    X = np.nan_to_num(np.array([feats(w, 'hepsi') for _, _, w in ck]))
    res['etiket_karisik'], _ = cv(X, yy, g)
    # karşılaştırma: içerik (kelimelerin kendisi)
    tf = TfidfVectorizer(min_df=2, sublinear_tf=True)
    T = tf.fit_transform([' '.join(w).lower() for _, _, w in ck])
    p = cross_val_predict(LogisticRegression(max_iter=3000), T, y, groups=g, cv=GroupKFold(5))
    res['icerik_kelimeler'] = balanced_accuracy_score(y, p)
    out['dogruluk'] = {k: round(float(v), 3) for k, v in res.items()}
    # sınıf bazında doğruluk (biçim özellikleri)
    out['sinif_dogruluk'] = {c: round(float(np.mean(pbest[y == c] == c)), 3) for c in classes}
    return out

if __name__ == '__main__':
    R = [run('Brown (İngilizce, 15 tür)', load_brown()), run('TTC-3600 (Türkçe, 6 haber kategorisi)', load_ttc())]
    # Brown: bilimsel vs felsefi/edebi ikili test
    b = [d for d in load_brown() if d[0] in ('learned', 'belles_lettres', 'religion')]
    R.append(run('Brown: bilimsel/akademik vs deneme-felsefe vs din', b))
    json.dump(R, open('/home/claude/sonuc.json', 'w'), ensure_ascii=False, indent=1)
    print(json.dumps(R, ensure_ascii=False, indent=1))
