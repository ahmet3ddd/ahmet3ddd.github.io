// Tarayıcıda çalışır. Girdi: window.TX[lang][cat] = [{id,text}]
window.ANALYZE = function (opt) {
  opt = opt || {};
  const CH = 200, K = opt.K || 3, WIDTH = 60;
  const LANGS = ['tr', 'en', 'de'];
  const CATS = Object.keys(TX.en);
  let seed = 7; const R = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
  const shuffle = a => { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(R() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
  const L = w => Math.max(1, (w.match(/[\p{L}\p{N}]/gu) || []).length);
  const hash = s => { let h = 0; for (const ch of s) h = (h * 31 + ch.charCodeAt(0)) >>> 0; return h; };

  // 1) parçalar
  const cells = {};
  for (const lg of LANGS) for (const c of CATS) {
    const arr = [];
    for (const d of TX[lg][c]) {
      const w = d.text.split(/\s+/).filter(Boolean);
      for (let k = 0; k < K && (k + 1) * CH <= w.length; k++) arr.push({ id: d.id, c, w: w.slice(k * CH, (k + 1) * CH) });
    }
    cells[lg + '|' + c] = arr;
  }
  const counts = Object.fromEntries(Object.entries(cells).map(([k, v]) => [k, v.length]));
  const N = Math.min(...Object.values(counts));
  const data = {};
  for (const lg of LANGS) { data[lg] = []; for (const c of CATS) data[lg].push(...shuffle([...cells[lg + '|' + c]]).slice(0, N)); }

  // 2) özellikler
  function layout(words) {
    const lines = []; let cur = [], pos = 0;
    for (const w of words) { const n = w.length; if (pos + n > WIDTH && pos > 0) { lines.push(cur); cur = []; pos = 0; } pos += n; cur.push(pos + 0.5); pos += 1; }
    lines.push(cur); return lines.map(l => l.slice(0, -1));
  }
  function river(words) {
    const ls = layout(words); const d = [];
    for (let i = 0; i + 1 < ls.length; i++) { const a = ls[i], b = ls[i + 1]; if (!a.length || !b.length) continue; for (const x of a) { let m = 1e9; for (const y of b) m = Math.min(m, Math.abs(y - x)); d.push(m); } }
    if (!d.length) return [0, 0, 0];
    const s = [...d].sort((p, q) => p - q);
    return [d.reduce((p, q) => p + q, 0) / d.length, s[Math.floor(s.length / 2)], d.filter(x => x <= 1).length / d.length];
  }
  const mean = a => a.reduce((p, q) => p + q, 0) / a.length;
  function feats(words, kind) {
    const l = words.map(L), n = l.length, m = mean(l);
    const sd = Math.sqrt(mean(l.map(x => (x - m) ** 2)));
    if (kind === 'ort') return [m];
    if (kind === 'gorsel') return river(words);
    const h = new Array(15).fill(0); l.forEach(x => h[Math.min(x, 15) - 1]++);
    const base = [...h.map(x => x / n), m, sd, l.filter(x => x <= 3).length / n, l.filter(x => x >= 8).length / n];
    if (kind === 'hist') return base;
    let cxy = 0; for (let i = 0; i + 1 < n; i++) cxy += (l[i] - m) * (l[i + 1] - m);
    const seq = [sd ? cxy / (n - 1) / (sd * sd) : 0];
    const tr = new Array(9).fill(0); const b = x => x < 4 ? 0 : x < 8 ? 1 : 2;
    for (let i = 0; i + 1 < n; i++) tr[b(l[i]) * 3 + b(l[i + 1])]++;
    seq.push(...tr.map(x => x / (n - 1)));
    if (kind === 'sira') return [...base, ...seq];
    return [...base, ...seq, ...river(words)]; // hepsi
  }

  // 3) çok sınıflı lojistik regresyon
  function standardize(Xtr, Xte) {
    const d = Xtr[0].length, mu = new Array(d).fill(0), sg = new Array(d).fill(0);
    Xtr.forEach(x => x.forEach((v, j) => mu[j] += v / Xtr.length));
    Xtr.forEach(x => x.forEach((v, j) => sg[j] += (v - mu[j]) ** 2 / Xtr.length));
    const f = x => x.map((v, j) => sg[j] > 1e-12 ? (v - mu[j]) / Math.sqrt(sg[j]) : 0);
    return [Xtr.map(f), Xte.map(f)];
  }
  function trainLR(X, y, C) {
    const d = X[0].length + 1, W = Array.from({ length: C }, () => new Array(d).fill(0));
    const mW = W.map(r => r.map(() => 0)), vW = W.map(r => r.map(() => 0));
    const lr = 0.05, lam = 1e-3;
    for (let it = 1; it <= 400; it++) {
      const G = W.map(r => r.map(() => 0));
      for (let i = 0; i < X.length; i++) {
        const x = [...X[i], 1]; const z = W.map(r => r.reduce((s, w, j) => s + w * x[j], 0));
        const mx = Math.max(...z); const e = z.map(v => Math.exp(v - mx)); const se = e.reduce((p, q) => p + q, 0);
        for (let k = 0; k < C; k++) { const g = e[k] / se - (y[i] === k ? 1 : 0); for (let j = 0; j < d; j++) G[k][j] += g * x[j] / X.length; }
      }
      for (let k = 0; k < C; k++) for (let j = 0; j < d; j++) {
        const g = G[k][j] + lam * W[k][j];
        mW[k][j] = 0.9 * mW[k][j] + 0.1 * g; vW[k][j] = 0.999 * vW[k][j] + 0.001 * g * g;
        W[k][j] -= lr * (mW[k][j] / (1 - 0.9 ** it)) / (Math.sqrt(vW[k][j] / (1 - 0.999 ** it)) + 1e-8);
      }
    }
    return x => { x = [...x, 1]; const z = W.map(r => r.reduce((s, w, j) => s + w * x[j], 0)); return z.indexOf(Math.max(...z)); };
  }
  function balAcc(y, p, C) { const r = []; for (let k = 0; k < C; k++) { const idx = y.map((v, i) => v === k ? i : -1).filter(i => i >= 0); if (idx.length) r.push(idx.filter(i => p[i] === k).length / idx.length); } return mean(r); }
  function perClass(y, p, C) { const r = {}; for (let k = 0; k < C; k++) { const idx = y.map((v, i) => v === k ? i : -1).filter(i => i >= 0); r[CATS[k] || k] = +(idx.filter(i => p[i] === k).length / idx.length).toFixed(3); } return r; }
  function cvLR(X, y, groups, C) {
    const fold = groups.map(g => hash(g) % 5), p = new Array(y.length);
    for (let f = 0; f < 5; f++) {
      const tr = [], te = []; fold.forEach((v, i) => (v === f ? te : tr).push(i));
      const [Xa, Xb] = standardize(tr.map(i => X[i]), te.map(i => X[i]));
      const m = trainLR(Xa, tr.map(i => y[i]), C); te.forEach((i, k) => p[i] = m(Xb[k]));
    }
    return p;
  }
  // içerik karşılaştırması: multinomial Naive Bayes
  function cvNB(docs, y, groups, C) {
    const fold = groups.map(g => hash(g) % 5), p = new Array(y.length);
    const tok = docs.map(w => w.map(x => x.toLowerCase().replace(/[^\p{L}\p{N}]/gu, '')).filter(Boolean));
    for (let f = 0; f < 5; f++) {
      const cnt = Array.from({ length: C }, () => new Map()), tot = new Array(C).fill(0), prior = new Array(C).fill(0), V = new Set();
      tok.forEach((t, i) => { if (fold[i] === f) return; prior[y[i]]++; t.forEach(w => { cnt[y[i]].set(w, (cnt[y[i]].get(w) || 0) + 1); tot[y[i]]++; V.add(w); }); });
      tok.forEach((t, i) => {
        if (fold[i] !== f) return; let best = -1, bs = -Infinity;
        for (let k = 0; k < C; k++) { let s = Math.log(prior[k]); t.forEach(w => { if (V.has(w)) s += Math.log(((cnt[k].get(w) || 0) + 1) / (tot[k] + V.size)); }); if (s > bs) { bs = s; best = k; } }
        p[i] = best;
      });
    }
    return p;
  }

  const out = { parca_hucre_basina: N, ham_sayilar: counts, kategoriler: CATS, sans: +(1 / CATS.length).toFixed(3), diller: {} };
  const kinds = ['ort', 'hist', 'sira', 'gorsel', 'hepsi'];
  const FX = {};
  for (const lg of LANGS) {
    const D = data[lg], y = D.map(d => CATS.indexOf(d.c)), g = D.map(d => d.id), C = CATS.length;
    const res = {}; let pBest;
    for (const k of kinds) { const X = D.map(d => feats(d.w, k)); const p = cvLR(X, y, g, C); res[k] = +balAcc(y, p, C).toFixed(3); if (k === 'hepsi') { pBest = p; FX[lg] = X; } }
    const Xs = D.map(d => feats(shuffle([...d.w]), 'hepsi')); res.hepsi_karisik = +balAcc(y, cvLR(Xs, y, g, C), C).toFixed(3);
    const ys = shuffle([...y]); res.etiket_karisik = +balAcc(ys, cvLR(FX[lg], ys, g, C), C).toFixed(3);
    res.icerik_kelimeler = +balAcc(y, cvNB(D.map(d => d.w), y, g, C), C).toFixed(3);
    // bilim vs felsefe ikili
    const bi = D.map((d, i) => (d.c === 'bilim' || d.c === 'felsefe') ? i : -1).filter(i => i >= 0);
    const yb = bi.map(i => D[i].c === 'bilim' ? 1 : 0);
    res.bilim_vs_felsefe = +balAcc(yb, cvLR(bi.map(i => FX[lg][i]), yb, bi.map(i => g[i]), 2), 2).toFixed(3);
    // profil
    const prof = {};
    for (const c of CATS) {
      const S = D.filter(d => d.c === c);
      const ml = S.map(d => mean(d.w.map(L)));
      const rv = S.map(d => river(d.w));
      prof[c] = { ort_uzunluk: +mean(ml).toFixed(3), kisa_oran: +mean(S.map(d => d.w.filter(x => L(x) <= 3).length / CH)).toFixed(3), uzun_oran: +mean(S.map(d => d.w.filter(x => L(x) >= 8).length / CH)).toFixed(3), yatay_mesafe: +mean(rv.map(r => r[0])).toFixed(3), dikey_oran: +mean(rv.map(r => r[2])).toFixed(3) };
    }
    // makale başına ort. uzunluk (istatistik testi için)
    const art = {};
    for (const c of CATS) { const m = {}; D.filter(d => d.c === c).forEach(d => { (m[d.id] = m[d.id] || []).push(mean(d.w.map(L))); }); art[c] = Object.values(m).map(a => +mean(a).toFixed(3)); }
    const ml = D.map(d => mean(d.w.map(L))), rd = D.map(d => river(d.w)[0]);
    const mx = mean(ml), my = mean(rd); let sxy = 0, sxx = 0, syy = 0; ml.forEach((x, i) => { sxy += (x - mx) * (rd[i] - my); sxx += (x - mx) ** 2; syy += (rd[i] - my) ** 2; });
    out.diller[lg] = { dogruluk: res, sinif_dogruluk: perClass(y, pBest, C), profil: prof, uzunluk_dallanma_r: +(sxy / Math.sqrt(sxx * syy)).toFixed(3), makale_ort: art };
  }
  // 4) diller arası ortak şablon: bir dilde öğren, diğerinde dene (her dil kendi içinde standardize)
  const cross = {};
  for (const a of LANGS) for (const b of LANGS) {
    if (a === b) { cross[a + '>' + b] = out.diller[a].dogruluk.hepsi; continue; }
    const ya = data[a].map(d => CATS.indexOf(d.c)), yb = data[b].map(d => CATS.indexOf(d.c));
    const sa = standardize(FX[a], FX[a])[0], sb = standardize(FX[b], FX[b])[0];
    const m = trainLR(sa, ya, CATS.length); const p = sb.map(m);
    cross[a + '>' + b] = +balAcc(yb, p, CATS.length).toFixed(3);
  }
  out.diller_arasi = cross;
  return out;
};
