// Uc dilli derlemin toplanmasi (22 Kasim 2026'da kullanilan adimlar).
// Calistirma: tarayicida https://en.wikipedia.org sayfasi acikken gelistirici konsoluna yapistirin.
// Sonuc: window.SEL (kategori -> 94 makale, en/tr/de basliklari) ve window.TX[dil][kategori] = [{id, text}].
// Ardindan 2-analiz.js dosyasindaki ANALYZE() calistirilir.

(async () => {
  // 1) Kategoriler: Wikipedia "Vital articles / Level 4" listesinin bolumleri
  const B = 'Wikipedia:Vital articles/Level 4/';
  const spec = {
    felsefe: [['Philosophy and religion', 2]],
    din: [['Philosophy and religion', 21]],
    bilim: [['Physical sciences', 113], ['Physical sciences', 47], ['Biology and health sciences', 24],
            ['Biology and health sciences', 25], ['Biology and health sciences', 33], ['Biology and health sciences', 39]],
    edebiyat: [['Arts', 13]],
    ekonomi: [['Society and social sciences', 5]],
    spor: [['Everyday life', 28]]
  };
  window.CAT = {};
  for (const [c, list] of Object.entries(spec)) {
    const s = new Set();
    for (const [p, i] of list) {
      const r = await fetch(`/w/api.php?action=parse&page=${encodeURIComponent(B + p)}&section=${i}&prop=links&format=json`).then(r => r.json());
      r.parse.links.filter(l => l.ns === 0 && l.exists !== undefined).forEach(l => s.add(l['*']));
    }
    CAT[c] = [...s];
  }

  // 2) Uc dilde de karsiligi olan makaleler (dil baglantilari)
  async function ll(titles, lang) {
    const m = {};
    for (let i = 0; i < titles.length; i += 50) {
      let cont = {};
      do {
        const q = new URLSearchParams({ action: 'query', redirects: 1, prop: 'langlinks', lllang: lang, lllimit: 'max', titles: titles.slice(i, i + 50).join('|'), format: 'json', ...cont });
        const r = await fetch('/w/api.php?' + q).then(r => r.json());
        for (const pg of Object.values(r.query.pages)) if (pg.langlinks) m[pg.title] = pg.langlinks[0]['*'];
        cont = r.continue || null;
      } while (cont);
    }
    return m;
  }
  window.LL = {};
  for (const c in CAT) {
    const a = await ll(CAT[c], 'tr'), b = await ll(CAT[c], 'de');
    LL[c] = Object.keys(a).filter(t => b[t]).map(t => ({ en: t, tr: a[t], de: b[t] }));
  }

  // 3) Her kategoriden 94 makale (en az olan felsefe = 94), sabit tohumlu karistirma
  function rng(s) { return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; }
  const R = rng(42);
  window.SEL = {};
  for (const c in LL) {
    const a = [...LL[c]];
    for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(R() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
    SEL[c] = a.slice(0, 94);
  }

  // 4) Duz metinlerin indirilmesi (her dil ayri kuyruk, istekler arasi bekleme)
  const STOP = /^(See also|References|Notes|Further reading|External links|Bibliography|Sources|Ayrıca bakınız|Kaynakça|Notlar|Dış bağlantılar|Kaynaklar|Siehe auch|Literatur|Weblinks|Einzelnachweise|Anmerkungen|Quellen)$/i;
  const clean = t => {
    const out = [];
    for (let l of t.split('\n')) {
      l = l.trim();
      const h = l.match(/^=+\s*(.*?)\s*=+$/);
      if (h) { if (STOP.test(h[1])) break; continue; } // baslik satirlari atilir, kaynakca bolumunde durulur
      if (l) out.push(l);
    }
    return out.join('\n');
  };
  window.TX = { en: {}, tr: {}, de: {} };
  for (const lg in TX) for (const c in SEL) TX[lg][c] = [];
  const sleep = ms => new Promise(s => setTimeout(s, ms));
  await Promise.all(['en', 'tr', 'de'].map(async lg => {
    const Q = [];
    for (const c in SEL) for (const a of SEL[c]) Q.push([c, a.en, a[lg]]);
    while (Q.length) {
      const [c, id, t] = Q[0];
      const q = new URLSearchParams({ action: 'query', prop: 'extracts', explaintext: 1, redirects: 1, titles: t, format: 'json', origin: '*' });
      const r = await fetch(`https://${lg}.wikipedia.org/w/api.php?` + q);
      if (r.status === 429) { await sleep(15000); continue; }
      const j = await r.json();
      const pg = Object.values(j.query.pages)[0];
      TX[lg][c].push({ id, text: clean(pg.extract || '') });
      Q.shift();
      await sleep(400);
    }
  }));
  console.log('tamam', Object.fromEntries(Object.entries(TX).map(([l, o]) => [l, Object.values(o).reduce((s, a) => s + a.length, 0)])));
})();
