 PImage img,img2;
 String[] words;
 String url;
 int say2=0;
 int saytopla=0;
 int en=10;
 int k=0;
 int bas=0;
 int satir=0;
 int kelime=0;
  void setup() {
  size(550, 750);
  strokeWeight(1);
  stroke(180,150,100);
  noFill();
  img = loadImage("kayit.jpg");
  img2 = loadImage("ac.jpg");
}
  void mousePressed() {
    say2=0;
    saytopla=0;
    en=10;
    k=0;
    bas=0;
  if ((mouseX > 300 && mouseX < 380) && (mouseY > 670 && mouseY < 690)&& (mouseButton == LEFT)){
       selectInput("Analizi Yapılacak Dosyayı Seçin:", "fileSelected",dataFile("*.txt"));
  }
  if ((mouseX > 400 && mouseX < 480) && (mouseY > 670 && mouseY < 690)&& (mouseButton == LEFT)){
    save("okudeneme.png");
  }
  }
  void fileSelected(File selection) {
  if (selection == null) {
    println("Window was closed or the user hit cancel.");
  } else {
   url = selection.getAbsolutePath();
  String[] text = loadStrings(url);
  String fullText = join(text, " " );
  words = splitTokens(fullText);
  kelime = words.length;
  satir = text.length;
  redraw();
   }
}
void draw() {
background(100);
image(img,400, 670);
image(img2,300, 670);
  for (k =0 ; k<kelime ; k++)
  {
    bas++;
    if(k == kelime-1) noLoop();
    int say = words[k].length();
    saytopla = saytopla + say;
    say = say*10;
      rect(say2, en,say, 10);
      fill(255); //................. kelime aralarını boyuyor
    //rect(say2-10, en,10, 10);// ...kelime aralarını kare olarak çiziyor
      rect(say2-10, en,10, 15);// ...kelime aralarını dikey dikdörtgen olarak çiziyor
      noFill();
      if (((saytopla+bas)*10) > width){
      en=en+15;
      say2=0;
      saytopla=0;
      bas=0;
    }else{ 
    say2 = (saytopla*10)+(10*bas);
    }
    }
text ("Analizi Yapılan Dosya Adı ...... : " + url ,10,720);
text ("Analizi Yapılan Kelime Sayısı . : " + kelime ,10,740);
}
