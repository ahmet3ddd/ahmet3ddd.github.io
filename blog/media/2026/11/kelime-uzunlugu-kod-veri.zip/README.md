# Kelime uzunluğu bir metnin konusunu ele verir mi? Üç dilde bir sınama

Ahmet Çandöken (ORCID 0009-0001-5197-7888) · ahmetoff.com · 22 Kasım 2026

Bu arşiv, makalenin (`kelime-uzunlugu-makale.pdf`) kodlarını, sonuçlarını ve 2021'deki ilk programı içerir.

## İçerik

| Yol | Açıklama |
| --- | --- |
| `2021-processing/data_okumak_blok_Son.pde` | 2021 Processing programı. Bir TXT dosyasını açar, her kelimeyi harf sayısıyla orantılı bir dikdörtgen olarak çizer (harf başına 10 px, 550 px satır). `ac.jpg` ve `kayit.jpg` düğme görselleridir, `ornek-cikti.png` örnek çıktıdır. Processing 3 ya da 4 ile açılır. |
| `kod/1-veri-toplama.js` | Wikipedia "Vital articles, Level 4" listesinden 6 kategori × 94 makaleyi seçer ve Türkçe, İngilizce, Almanca düz metinlerini indirir. en.wikipedia.org açıkken tarayıcı konsolunda çalıştırılır. |
| `kod/2-analiz.js` | `ANALYZE()`: parçalama (200 kelime, makale başına en fazla 3, hücre başına eşit sayı), biçim ölçüleri, çok sınıflı lojistik regresyon, makaleye göre gruplanmış 5 katlı çapraz doğrulama, kontroller, diller arası aktarım. Aynı tarayıcı oturumunda `1-veri-toplama.js`'ten sonra çalışır. |
| `kod/ilk-deneme-brown-ttc3600.py` | İlk deneme: Brown derlemi (İngilizce, 15 tür) ve TTC-3600 (Türkçe haber, 6 kategori). Python 3, numpy, scikit-learn. |
| `sonuclar/sonuclar-3dil.json` | Üç dilli denemenin bütün sayıları (makaledeki tabloların kaynağı). |
| `sonuclar/ilk-deneme-brown-ttc3600.json` | İlk denemenin sayıları. |
| `makale-listesi.tsv` | Ayrı dosya olarak kayıtta: kullanılan 564 makalenin kategori, İngilizce, Türkçe ve Almanca başlıkları. |

## Notlar

- Wikipedia metinleri yeniden dağıtılmamıştır (CC BY-SA 4.0). Aynı başlıklar `1-veri-toplama.js` ile yeniden indirilebilir. Makaleler zamanla değiştiğinden sayılar küçük farklarla yeniden üretilir.
- Brown ve TTC-3600 derlemleri bu arşivde yoktur. Kaynakları betiğin başında yazılıdır.
- Veri toplama, analiz kodu ve istatistik testleri yazarın yönlendirmesiyle Anthropic'in Claude modeli kullanılarak yapılmıştır. Hakemli inceleme yoktur.

## Lisans

Kod: MIT. Metin ve sonuçlar: CC BY 4.0. Hukuka aykırı amaçlarla kullanılamaz.

## Atıf

Çandöken, A. (2026). *Kelime uzunluğu bir metnin konusunu ele verir mi? Üç dilde bir sınama.* Zenodo. https://doi.org/10.5281/zenodo.24440619
